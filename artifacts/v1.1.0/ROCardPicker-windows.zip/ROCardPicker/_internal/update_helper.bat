@echo off
setlocal EnableExtensions
REM Args: <PID> <NEW_DIR> <INSTALL_DIR> <EXE_PATH>
set "APP_PID=%~1"
set "NEW_DIR=%~2"
set "INSTALL_DIR=%~3"
set "EXE_PATH=%~4"

if "%APP_PID%"=="" goto fail
if "%NEW_DIR%"=="" goto fail
if "%INSTALL_DIR%"=="" goto fail
if "%EXE_PATH%"=="" goto fail

echo Waiting for process %APP_PID% to exit...
set /a _tries=0
:wait
set /a _tries+=1
tasklist /FI "PID eq %APP_PID%" | findstr /I "%APP_PID%" >nul
if not errorlevel 1 (
  if %_tries% GEQ 120 (
    echo Timed out waiting for the app to close.
    goto fail
  )
  timeout /t 1 /nobreak >nul
  goto wait
)

timeout /t 1 /nobreak >nul

if not exist "%NEW_DIR%\ROCardPicker.exe" (
  echo New build is missing ROCardPicker.exe
  goto fail
)

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

robocopy "%NEW_DIR%" "%INSTALL_DIR%" /E /IS /IT /NFL /NDL /NJH /NJS /NC /NS /NP
set "RC=%ERRORLEVEL%"
if %RC% GEQ 8 (
  echo robocopy failed with code %RC%
  goto fail
)

start "" "%EXE_PATH%"
exit /b 0

:fail
echo Update failed. You can start the app again manually.
if exist "%EXE_PATH%" start "" "%EXE_PATH%"
exit /b 1
